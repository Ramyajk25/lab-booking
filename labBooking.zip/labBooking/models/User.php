<?php
class User extends BusinessObject
{
    private $_db;
    
    public function __Construct($db = null) {
        if ($db != null) {
            $this->_db = $db;
        }
		else {
			$this->_db = $this->_db();
		}
    }
    
    private function _setUserId($id) {
        $this->_userId = $id;
    }
    
    public function getUserId() {
        $this->_userId;
    }
 
	/**
     * getUserByName - Used to get the User data by user_name
     * @param: $userId - integer - user_id
     * @return: $userData - Object - Details of User
     */
    public function getUserByName($userName) 
	{
		$userName = $this->_db->escape_string($userName);
      
		if(empty($userName))
		{
			return false;
		}
		
        $userData = array();
        $sql = "SELECT * 
                FROM users 
                WHERE user_name = '" . $userName . "' 
                AND user_status = 1 LIMIT 1";
       
        $result = $this->_db->query($sql);
        
        if ($result && $this->_db->numrows($result)) {
            while ($userData = $this->_db->fetch($result)) {
               return $userData;
            }
        }
        return $userData;
    }
    
    
    /**
     * getUserName - used to get the User name of specific user.
     * @param: $id - int - user_id.
     * @return: $userData - object - name
     */
    public function getUserNameId($id){
    	$id = $this->validateInteger($id);
		
        if(empty($id))
		{
			return false;
		}
		
    	$sql = "SELECT user_name as name, user_id as userId 
                FROM users 
                WHERE user_id = ". $id . " AND user_status = 1 
                LIMIT 1";
                
    	$result = $this->_db->query($sql);
        
        if ($this->_db->numrows($result)) {
            while ($userData = $this->_db->fetch($result)) {
               return $userData;
            }
        }
        return false;
    }
	


	/**
     * insertUserDetails - used to insert User details.
     * @param: $user - array - $_POST values.
     * @return: boolean.
    */
    public function insertUserDetails($userName, $password)
    {   
        $userName = $this->_db->escape_string($userName);
		$password = $this->_db->escape_string($password);
		
		//Create random salt for password
		$random_salt = hash('sha512', uniqid(mt_rand(1, mt_getrandmax()), true));
		// Create salted password (Careful not to over season)
        $salted_password = hash('sha512', $password . $random_salt);
		

		$createdOn = date('Y-m-d H:i:s');
		$sql   = "insert into users (user_name, password, salt, user_status, created_on) values ( 
										  '" . $this->_db->escape_string($userName) . "',
										  '" . $salted_password . "', 
										  '" . $random_salt . "',  1, 
										  '" . $createdOn . "');";
										 // echo $sql;exit;
										  
		$userResult = $this->_db->query($sql); //var_dump($userResult);
        if (!empty($userResult)) 
        {
            return true;
        }
        return false;
	}
	
	/**
     * isUserExists - used to get Ambassador id's from ppo_users table.
     * @param: $id - int - user_id.
     * @return: number of rows of result.
     */ 
    public function isUserExists($userName)
    {
        if(empty($userName))
		{
			return false;
		}
		
		$sql = "SELECT user_id 
                FROM users 
                WHERE user_name = '" . $userName . "' AND 
				user_status = 1 LIMIT 1";
         
        $result = $this->_db->query($sql);
        //var_dump($result);exit; 
        if(!empty($result)){
            return $this->_db->numrows($result);
        }
        return 0;
    }
    
        
    /**
     * _getMaxId - Used to get maximum value of id.
     * @return: $number->id + 1 - maximun id value incremented by 1.
     */
    private function _getMaxUserId(){
        $sql = "SELECT max(user_id) as id FROM users";
        $result = $this->_db->query($sql);
        if(!empty($result)){
            while ($number = $this->_db->fetch($result)) {
               return $number->id + 1;
            } 
        }
        return 0;
    }

}

?> 