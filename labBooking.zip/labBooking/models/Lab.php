<?php
/**
 * UserController: All actions related to lab booking like 
 * Add/Edit/fetch lab booking details
 *  @Author: Sugashri Narayanasamy
 */
class Lab extends BusinessObject
{
    private $_db;
    
    public function __Construct($db = null) {
        if ($db != null) {
            $this->_db = $db;
        }
		else {
			$this->_db = $this->_db();
		}
    }
    
    private function _setUserId($id) {
        $this->_userId = $id;
    }
    
    public function getUserId() {
        $this->_userId;
    }
				
	/**
     * getLabBookingDetails - Used to get the lab booking Details
     * @param: $labTypeId-
     * @return: $bookedDetails - Array - Details of lab booking details
     */
    public function getLabBookingDetails($labTypeId) 
	{
		$bookedDetails = array();
        $sql = "SELECT lab_booking_id,  booking_name as title, user_name, booked_start_time, booked_end_time, user_id, user_name, lab_type_id as labTypeId, type_name 
                FROM lab_booking_details lbd 
				JOIN lab_type lt on lbd.type_id = lt.lab_type_id 
				JOIN users u on u.user_id = lbd.created_by 
				WHERE u.user_status = 1 AND lt.status = 1 AND lbd.status = 1 AND lbd.booked_start_time >= now()";

        $result = $this->_db->query($sql);

        if ($result && $this->_db->numrows($result)) {
			$i = 0;
            while ($events = $this->_db->fetch($result)) {
				$bookedDetails[$i]['id'] = $events->lab_booking_id;
				$bookedDetails[$i]['parentId'] = $events->labTypeId;
                $bookedDetails[$i]['title'] = $events->title;
				$bookedDetails[$i]['start'] = $events->booked_start_time;
				$bookedDetails[$i]['end']   = $events->booked_end_time;
				$bookedDetails[$i]['userId'] = $events->user_id;
				$bookedDetails[$i]['labTypeName'] = $events->type_name;
				$bookedDetails[$i]['description'] = " By " . $events->user_name;
				$bookedDetails[$i]['color'] = '#5bbaf4';//'#'.substr(uniqid(),-6);
				$i++;
            }
        }
        return $bookedDetails;
    }
	
	
	/**
     * getLabType - Used to get the job category Details
     * @param: 
     * @return: $labType - Array- Details of lab types
     */
    public function getLabType() 
	{
		$labType = array();
        $sql = "SELECT * 
                FROM lab_type 
				WHERE status = 1";
       
        $result = $this->_db->query($sql);
        
        if ($result && $this->_db->numrows($result)) {
            while ($category = $this->_db->fetch($result)) {
                $labType[$category->lab_type_id] = $category->type_name;
            }
        }
        return $labType;
    }
	
	/**
     * insertLabBookingDetails - used to insert lab booking details.
     * @param: $bookingData - array - $_POST values, $userId-session (loggedin).
     * @return: boolean.
    */
    public function insertLabBookingDetails($bookingData, $userId)
    {
		$title = $this->_db->escape_string($bookingData['bookedTitle']);
		$start = $this->_db->escape_string($bookingData['startBooking']);
		$end   = $this->_db->escape_string($bookingData['endBooking']);
		$labTypeId = $this->_db->escape_string($bookingData['labTypeId']);
		
		$createdOn = date('Y-m-d H:i:s');
		$sql   = "insert into lab_booking_details (booking_name, type_id, booked_start_time, booked_end_time, created_by, created_on, status) values ( 
										  '" . $title . "',
										  '" . $labTypeId . "', 
										  '" . $start . "', 
										  '" . $end . "',  
										  '" . $userId . "',
										  '" . $createdOn . "', 1);";
										  
		$userResult = $this->_db->query($sql); 
        if (!empty($userResult)) 
        {
            return true;
        }
        return false;
	}
	
	/**
     * updateLabBookingDetails - used to update booking details.
     * @param: $bookingData - array - $_POST values, $userId-session (loggedin).
     * @return: boolean.
    */
    public function updateLabBookingDetails($bookingData, $userId)
    {
		$title = $this->_db->escape_string($bookingData['bookedTitle']);
		$start = $this->_db->escape_string($bookingData['startBooking']);
		$end   = $this->_db->escape_string($bookingData['endBooking']);
		$labTypeId = $this->_db->escape_string($bookingData['labTypeId']);
		$bookedId = $this->_db->escape_string($bookingData['bookedId']);
		if(empty($bookedId))
		{//if bookedId missing donot update the details
			return false;
		}
		$createdOn = date('Y-m-d H:i:s');
		$sql   = "UPDATE lab_booking_details SET 
									booking_name = '" . $title . "', 
									booked_start_time = '" . $start . "', 
									booked_end_time = '" . $end . "',
									created_by = '" . $userId . "', 
									created_on = '" . $createdOn . "'
									WHERE lab_booking_id = " . $bookedId . ";";
										  
		$userResult = $this->_db->query($sql); 
        if (!empty($userResult)) 
        {
            return true;
        }
        return false;
	}
}
?>