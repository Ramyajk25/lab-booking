<?php

/**
 * The BusinessObject class is the parent of all logical business entities.
 */

abstract class BusinessObject
{
    public function __construct()
    {
        // You cannot store a resource, such as a database connection, in a 
        // cached object.  Because while the cache will persist the reference 
        // beyond the page request, the database connection will close at the 
        // end of the request.  This means that when the object is retrieved 
        // from cache and tries to use the resource, it will be closed. The log 
        // file is also a resource.  Must get these variables from the registry 
        // every time.
    }

    // convenience methods
    protected function _logger()
    {
       $logger = new Logger();
       return $logger;
    }

    protected function _db()
    {
        //$dsn = 'mysql://root:@localhost/annsummers';
        $db = new DB();
        return $db;
    }
    
    protected function _constant()
    {
       $constant = new Constant();
       return $constant;
    }
    
    public function validateInteger($dirty, $return = false) {
        if (!isset($dirty)) return;
        //removes non-printable ascii chars (except \t, \r and \n) and backticks
        $dirty = preg_replace("/[\x01-\x08\x0b\x0c\x0e-\x1f\x60]+/","",$dirty);
		
		if ($return) 
			return $dirty;
			
        return (int) $dirty;
    }
}

