<?php
require_once(APP_ROOT . "/thirdpartylibs/Smarty/libs/Smarty.class.php");  
// Global function declarations
require_once(__SMARTY_DIR . "/functions.php");
require_once(__SMARTY_DIR . "/Smarty.php");
       
/**
 * Smarty wrapper class, simply enables syntax like:
 *
 * $smarty->title = "My Title";
 *
 * instead of:
 *
 * $smarty->assign('title', "My Title");
 */

class SmartyView extends \Smarty\Smarty
{
    public function __construct($mode)
    {
		parent::__construct();

        $this->use_sub_dirs = true;
       
        // if developing, always re-compile templates
        $this->debugging = false;
		$this->force_compile =($mode != 'production') ? true : false;                  
        $this->template_dir = array(APP_ROOT . "/views/");
    }

    public function __set($var, $value)
    {
		$this->assign($var, $value);
    }
}








