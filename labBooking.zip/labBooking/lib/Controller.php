<?php

/**
 * This is the parent controller class of all controllers. It sets up the view 
 * system (implemented by Smarty), and provides a catch-all method that returns 
 * a 404 Not Found. This catch-all method can be overridden in the child 
 * controller.
 */

abstract class Controller
{
    public $view;
    public $loggedIn;
    public $userId;
	public $db;
	
    
    public function __construct($module)
    {     
	
		$this->db = new DB();
        $this->view = new SmartyView("dev");        
        $templateDir[] = APP_ROOT . "/views";
		$this->view->debugging= true;

        // partner template dir must be first to override core templates
        $this->view->template_dir = $templateDir;
        $this->view->module = $module;
       
        $loggedIn = false;
        if (isset($_SESSION["login_string"], $_SESSION["user_id"]))  {
            $loggedIn = true;
            $this->view->userId = $_SESSION["user_id"];
              
        }
        
        if (isset($_GET["err"]) && $_GET["err"] == 1) {
           //$this->view->errMessage = "Please login to do process!!!";
        }
        
        $this->view->app_root = APP_ROOT;
        $this->view->loggedIn = $loggedIn;
        $this->view->web_root = Constants::DOMAIN;
    }
    
    public function error($accessError = false) {
        if (!$accessError) {
            setcookie("loggedIn", '', time() - 3600, "/");
            $script = "<script type='text/javascript'>";
            $script .= "alert('Kindly login to process!!');
                        location.href = 'http://" . Constants::DOMAIN . "/user/login';</script>";
        } 
        else {
			$homePage = '';
        }
        $this->db->destructor();
        echo $script;
    }
       
    /**
     * This method is called if a non-existent method (i.e. action) is called on 
     * this object.
     */

    public function __call($action, $args)
    {
		header('HTTP/1.0 404 Not Found');
        exit;
    }
}

