<?php

class DB {

    public $host;
    public $name;
    public $user;
    public $password;
    public $device;
    public $error;
    public $lastquery;

	function __Construct ($host = "localhost", $db = "labbooking", $user = "root", $pass = "") 
	{
        $this->device		= 0;
        $this->error		= "none";
        if (strstr($host, ":")) {
            list($this->host, $this->name, $this->user, $this->password) = split(":", $host);
        } else {	
            $this->host	= $host; 
            $this->name = $db;
            $this->user	= $user; 
            $this->password = $pass;
        }

        $this->device = mysqli_connect($this->host, $this->user, $this->password);


        if ($this->device) {
            mysqli_select_db( $this->device, $this->name);
        } else {
            $this->error = mysqli_error($this->device);
        }
        // register_shutdown_function('$this->destructor');
    }

    function connectionInUTF8(){
        mysqli_query("SET NAMES 'utf8';", $this->device);
        mysqli_query("SET CHARACTER SET utf8;", $this->device);
        mysqli_query("SET character_set_connection = utf8;", $this->device);
    }

    function showVars($con) {
        $result = mysqli_query("show variables", $con);
        while ($row = mysqli_fetch_row($result)) {
            if (strpos($row[0],'character_')!==false) {
                echo join(';', $row)."<br>";
            }
        }
    }


    function destructor() {
        if ($this->device) @$this->close();
    }

    public function query ($query) {
        $this->lastquery = $query;
        //var_dump($this->device);echo "<!-- pre>QUERY = '" . $query . "'\n";exit;
        
        if (!$result = mysqli_query($this->device, $query)) {
            $this->error = mysqli_error();
            //echo $this->error . "</pre -->";
        }
        return $result;
    }

    function fetch ($result) { 
        return mysqli_fetch_object($result); 
    }

    function fetch_array ($result, $format = 'MYSQL_ASSOC') {
        if ($format != '') {
            return mysqli_fetch_array($result, $format);
        } else {
            return mysqli_fetch_array($result);
        }
    }

    function fetch_row ($result) { 
        return mysqli_fetch_row($result); 
    }

    function numrows ($result) { 
        return mysqli_num_rows($result); 
    }

    function num_rows ($result) { 
        return mysqli_num_rows($result); 
    }

    function numfields ($result) { 
        return mysqli_num_fields($result); 
    }
    
    /**
     * fetch_field - returns number of rows affected by last query
     */
    function fetch_field ($result) { 
        return mysqli_fetch_field($result);
    }

    /**
     * affectedRows - returns number of rows affected by last query
     */
    function affectedRows () { 
        return mysqli_affected_rows($this->device);
    }

    /**
     * insertId - returns last inserted id to DB
     */
    function insertid ($table, $column) { 
        $sql = "SELECT max(" . $column . ") as id FROM " . $table . " LIMIT 1";
        $result = $this->query($sql);
        
        if (!empty($result)) {
            $data = $this->fetch($result);   
        }
        
        return $data->id;
    }
    
    /**
    * Wrapper method for escaping strings
    * @mixed
    * @mixed
    */
    function escape_string($string)
    {
        return mysqli_real_escape_string($this->device, $string);
    }   

    function close () { 
            return mysqli_close($this->device);
    }
}