<?php
class Router
{
    /** 
     * You can put any routing needs, such as a list of hard-coded routes 
     */
    public static function route($uri)
    {
        $arguments = array();
        // remove the query string, if any
        $uri = str_replace('?' . $_SERVER['QUERY_STRING'], '', $uri);
        
        $segments = explode('/', $uri);

        // these defaults should be set in config somehow?
        $module = (empty($segments[1])) ? 'home' : $segments[1];
        $action = (empty($segments[2])) ? (empty($_REQUEST["a"])? 'index' : $_REQUEST["a"]) : $segments[2];
        
        $controller = ucfirst($module) . 'Controller';
//	print $controller."---------------------".$module."===================". $action;exit;
        // if controller exists, call the action on it
        if (file_exists(APP_ROOT . "/controllers/$controller.php"))
        {
            header('Content-Type: text/html; charset=utf-8');
            $controller = new $controller($module);

            // the remaining "path segments" of the URI are passed as args to 
            // the action, 1 arg per path segment, in order
            call_user_func_array(array($controller, $action), $arguments);
        }
        // else return 404 Not Found
        else
        {
            header('HTTP/1.0 404 Not Found');
            exit;
        }
    }
}


?>