<?php
class Constants {
    const DOMAIN = "disabilityjobportal"; 
    const USER_STATUS = 1;    
    const SESSION_TIME_OUT = 15; //15 mins

  
}
?>