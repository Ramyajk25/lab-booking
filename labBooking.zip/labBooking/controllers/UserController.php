<?php
/**
 * UserController: All actions related to Users like login
 * Add/Edit/Delete/Search User
 *  @Author: Sugashri Narayanasamy
 */
class UserController extends Controller 
{
    public $user;
    private $error;
	private $role;
	private $userDetails;
	private $userProfileDetails;
	private $uploads_dir;
	private $uploadOk;
	private $profileName;
	private $fileSize;
	private $fileType;
    
    function __Construct() {
        parent::__Construct("user");
        $this->user = new User($this->db);		
    }
	
	public function index()
	{
		header("Location: /lab/");
		$this->view->title = "College Lab Booking";
		$this->view->heading = "Welcome to Lab Booking";
	  	$this->view->display("home\index.tpl");
	}
	
    /**
     * login - used for login.
     * 
     */
    public function login () 
	{
		$this->view->title = "Login";
		$this->view->heading = "User Login";
		//Check Post reqest set - then user trying to login.
        if (isset($_POST["username"], $_POST["password"])) 
		{
			//Verify if user details with DB
            if ($this->_userLogin()) {				
              header('Location: /user/');
			  $this->db->destructor();
            }
            else 
			{
                $this->view->error = $this->error; 
				$this->view->display("user\login.tpl");
				$this->db->destructor();
            }
        } else 
		{
			//Check if user already logged in,(session is there) then display Dashboard // resume upload.
            if (!$this->checkAuthenticate()) 
			{
                //Display login forms
                $this->view->error = $this->error;
				$this->view->display("user\login.tpl");
				$this->db->destructor();
                exit;
            } 
			else
			{ //Redirect to Dashboard where calendar will be displayed
				header("Location: /user/");
				$this->db->destructor();
			}
        }
        
    }
	
	/**
     * Register - used for Register the user details.
     *
     */
    public function register () 
	{
		if(!empty($_POST))	
		{ 
			//validate the post details with DB.
			$name = $_POST['name'];
			$password = $_POST['password'];
		
			if (!$this->user->isUserExists($name))
        	{  
		    	$userData  = $this->user->insertUserDetails($name, $password);
	            if (!empty($userData)) {
	                $_SESSION['success'] = 1;
                    header("Location: /user/login");
	            }
        	    else 
                {
                    $this->error = "Register is Not successful!.Please try again.";
                }
        	}
        	else 
        	{
        		$this->error  = "USERNAME/EMAIL ALREADY EXISTS.";				
        	}    
        }
		$this->view->error = $this->error;
		$this->view->title = "Sign Up";
		$this->view->heading = "New User Sign Up";
		$this->view->display("user\userRegister.tpl");	
		
    }
	
    /**
	 * Validate the password 
	*/
	private function _validatePassword($pwd)
    {
        $passwordRules =array('![0-9]+!', //one digit
							  '![a-z]+!', //one Lower char
							  '![A-Z]+!', //One upper char
							  '!\W+!'	  // One special char
							);
        //Bad Words
        $lower   = "abcdefghijklmnopqrstuvwxyz";
        $upper   = strtoupper($lower);
        $numbers = "0123456789";
        $qwerty  = "qwertyuiopasdfghjklzxcvbnm";
        $badwordsPattern = array($lower, $upper, $numbers, $qwerty);
        
		//If user enters 4 pin(only digits) then allow them to login
        if(strlen($pwd) === 4 && preg_match("![0-9]{4}!", $pwd)) 
        {
            return true;
        }
        //Length validation
        if( strlen($pwd) < 8 || strlen($pwd) > 12) {
            return false;
        }
        
		//Same char seq validation
        if(preg_match('/(.)\1\1/', $pwd))
        {
            return false;
        }
		
        foreach($passwordRules as $rule)
        {
            if(!preg_match($rule, $pwd) ) {
               return false;
            }
        }
        
        $len = strlen($pwd);
        foreach($badwordsPattern as $data) 
	    {
	       for($j=0; $j <= ($len - 3); $j++) 
	       {
				if(strpos($data, substr($pwd, $j, 3)) !== false)
				{
					$seq = substr($pwd, $j, 3);
				}
	       }   	  
		   if($seq)
		   {
				if (strpos($data, $seq) >= 0 )
				{
	                return false;
		        }
		   }       
	    }
        return true;
    }
	
    /**
     * _userLogin - used to check login details are matches with DB.
     * @return: boolean.
     */
    private function _userLogin() {
        $username = stripslashes($_POST["username"]);
        $password = stripslashes($_POST["password"]);
	    //$this->homePage = '';
        
        //Get the user details id, password, salt from DB by username
        $userData = $this->user->getUserByName($username);
		
        // If the user exists check the login attempt by the User.
        if(!empty($userData)) {
            $password = hash('sha512', $password . $userData->salt); 
                       
            // Check if the password in the database matches the password the user submitted. 
            if($userData->password == $password) { // Password is correct!
                // Get the user-agent string of the user
                $user_browser = $_SERVER['HTTP_USER_AGENT']; 
                
                // XSS protection as we might print this value
                $user_id = preg_replace("/[^0-9]+/", "", $userData->user_id);
                $username = preg_replace("/[^a-zA-Z0-9_\-]+/", "", 
                                            $userData->user_name);
                // regenerated the session, delete the old one after sucessful Login.  
				if (!empty(session_id())) {
					session_regenerate_id(true);    
				}
				else {
					session_start();
				}
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $username;
                $_SESSION['login_string'] = hash('sha512', $user_id.$user_browser);
                $_SESSION['loggedIn_time'] = time();
				
                // Login successful.
                return true;                
            } else { //password is incorrect
                $this->error = "Entered Password is incorrect.";              
                return false;
            }
        } 
		else {  // No User exists. 
            $this->error = "User name does not exists.Please <a href='register'>SIGN UP.</a>";
            return false;
        }
    }
	
    
    /**
     * checkAuthenticate - used for authentication.
	 * @return: boolean.
     */
    public function checkAuthenticate($id = '') {
        $loggedIn = false;
        $userId = 0;
		$login_string = '';
        
        // Check if all session variables are set
        if(isset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['login_string']) || (!empty($id))) {
            $user_id      = (!empty($id)) ? $id : $_SESSION['user_id'];
            $login_string = $_SESSION['login_string'];
            $username     = $_SESSION['username'];

            $user_browser = $_SERVER['HTTP_USER_AGENT']; // Get the user-agent string of the user.            
            $userData = $this->user->getUserNameId($user_id);
            
            if (isset($user_id)) {
                $login_check = hash('sha512', $userData->userId . $user_browser);
                if($login_check == $login_string || $login_check == $userData->login_string) {// Logged In!!!!
                    $loggedIn = true;
                    $userId = $userData->userId;
					$this->userDetails = $userData;
                }
            }
        }
        if (!empty($id)) {
            $this->db->destructor();
            echo $loggedIn;exit;
        }
        
        return $loggedIn;
    }
    
    /**
     * logout - used to logout.
     * @param: $id - int - Using User id value from session. 
     */
    public function logout($id = "") {
        $user_id = (!empty($id)) ? $id : $_SESSION["user_id"];
        
        // Unset all session values
        $_SESSION = array();
        // get session parameters 
        $params = session_get_cookie_params();
        // Delete the actual cookie.
        setcookie(session_name(), '', time() - 42000, 
                  $params["path"], $params["domain"], 
                  $params["secure"], $params["httponly"]);
        // Destroy session
        session_destroy();
		$this->db->destructor();
        header('Location: /lab/');
    }
}
?>