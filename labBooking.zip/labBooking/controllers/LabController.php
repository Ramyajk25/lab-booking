<?php
/**
 * JobController: All actions related to lab booking.
 * Add/Edit/Search lab Booking details.
 *  BY Sugashri Narayanasamy
 */
class LabController extends Controller 
{
	private $lab;
	public $user;
    private $error;
	
    function __Construct() {
        parent::__Construct("job");
        $this->lab = new Lab($this->db);	
		$this->user = new User($this->db);
	}
	
	/**
	 * when specific action is not mentioned default this function called.
	 * By default display calendar with events
	 */
	public function index()
	{
		//If user is not logged in redierect to login
		if(!isset($_SESSION['user_id']))
		{
			header("Location: /user/login");
		}
		
		$labType = isset($_REQUEST['labTypes']) ? $_REQUEST['labTypes'] : 1;
		$labTypeDetails = $this->lab->getLabType();
		
		$userId = $_SESSION['user_id'];
		
		$this->view->title = "College Lab Booking";
		$this->view->heading = "Lab Booking Calendar";
		$this->view->labTypes = $labTypeDetails; //print_r($eventsData);//exit;
		$this->view->labTypeId = $labType;
		$this->view->users = $this->user->getUserNameId($userId);
		$this->view->display("lab/calendar.tpl");
	}
	
	/**
	*	this function called as ajax to fetch booking details
	*   @return json code.
	*/
	
	public function displayEvents()
	{
		//If user is not logged in redierect to login
		if(!isset($_SESSION['user_id']))
		{
			header("Location: /user/login"); 
		}
		
		$data = array(
					'status' => false,
					'msg' => 'Error! while fetching lab booking details from DB'				
				);
		$labType = 	isset($_GET['labTypeId']) ? $_GET['labTypeId'] : 1;
		$userId = $_SESSION['user_id'];
		$labTypeDetails = $this->lab->getLabType();
		
		//Get all lab booked details
		$eventsData = $this->lab->getLabBookingDetails($labType);
		
		if (isset($eventsData)) 
		{
		  $data = array(
					'status' => true,
					'msg' => 'successfully!',
					'data' => $eventsData
				);
		  
		}
		
		echo json_encode($data);exit;
	}

	/**
	*	this function called as ajax to save booking details
	*   @return json code.
	*/
	public function saveEvent()
	{
		$return = 0;
		//Set error message as default return json 
		$data = array(
					'status' => false,
					'msg' => 'Sorry, booking details are not added.'				
				);
				
		if(!empty($_POST))
		{
			$userId = $_SESSION['user_id'];
			if(isset($_POST['bookedId']) && $_POST['bookedId'] != "")
			{//if bookedId exists, then update the details for that id.
				$return = $this->lab->updateLabBookingDetails($_POST, $userId);
			}
			else
			{//insert new event
				$return = $this->lab->insertLabBookingDetails($_POST, $userId);
			}
			
			if($return)
			{//if saved to DB return success JSON
				$data = array(
					'status' => true,
					'msg' => 'Lab is booked successfully!'
				);
			}
		}
		echo json_encode($data);exit;
	}
}
